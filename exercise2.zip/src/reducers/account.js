// account 的state应该什么样子？是根据你所打算的account的功能决定的
// 先设计account的样子，在决定他的reducer结构
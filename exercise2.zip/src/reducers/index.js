import account from './account'
import {combineReducers} from 'react-redux'

const root = combineReducers({
  account
})

export default root
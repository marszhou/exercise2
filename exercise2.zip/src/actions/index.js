import * as account from './account'

export default {
  account
}
import React, { Component } from 'react';

class Register extends Component {
  render() {
    return (
      <div>
        Register 如果已经登录成功再访问此页面则都跳转到LoginedPage
      </div>
    );
  }
}

export default Register;
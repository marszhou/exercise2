export default configureStore = () => {
  // ... 做什么？
}